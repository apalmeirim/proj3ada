import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        //Initializes the reader
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

        //Read input
        String[] input = in.readLine().split(" ");

        int thieves = Integer.parseInt(input[0]);
        int goldBars = Integer.parseInt(input[1]);
        int locations = Integer.parseInt(input[2]);
        int roads = Integer.parseInt(input[3]);

        Graph graph = new Graph(locations + 1);
        for(int i = 0; i < roads; i++){
            String[] route = in.readLine().split(" ");
            int l1 = Integer.parseInt(route[0]) ;
            int l2 = Integer.parseInt(route[1]);
            graph.addEdge(l1, l2);
            graph.addEdge(l2, l1);
        }

        String[] vaultDestination = in.readLine().split(" ");
        int vaultLoc = Integer.parseInt(vaultDestination[0]);
        int destinationLoc = Integer.parseInt(vaultDestination[1]);

        int numPaths;
        if(destinationLoc < vaultLoc){
            numPaths = graph.DinicMaxflow(destinationLoc, vaultLoc);
        }
        else{
            numPaths = graph.DinicMaxflow(vaultLoc, destinationLoc);
        }

        System.out.println(Math.min(thieves,numPaths)*goldBars);
    }
}