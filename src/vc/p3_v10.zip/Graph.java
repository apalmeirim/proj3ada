import java.util.*;

public class Graph {

    static class Edge {
        int to, capacity, flow, rev;

        public Edge(int to, int capacity, int rev) {
            this.to = to;
            this.capacity = capacity;
            this.flow = 0;
            this.rev = rev;
        }
    }

    @SuppressWarnings("unchecked")
    static class MaxFlow {
        int V;
        ArrayList<Edge>[] adj;

        public MaxFlow(int V) {
            this.V = V;
            adj = new ArrayList[V];
            for (int i = 0; i < V; i++) {
                adj[i] = new ArrayList<>();
            }
        }

        void addEdge(int u, int v, int capacity) {
            Edge a = new Edge(v, capacity, adj[v].size());
            Edge b = new Edge(u, 0, adj[u].size());
            adj[u].add(a);
            adj[v].add(b);
        }

        boolean bfs(int s, int t, int[] parent) {
            boolean[] visited = new boolean[V];
            Queue<Integer> queue = new LinkedList<>();
            queue.add(s);
            visited[s] = true;
            parent[s] = -1;

            while (!queue.isEmpty()) {
                int u = queue.poll();
                for (Edge edge : adj[u]) {
                    if (!visited[edge.to] && edge.flow < edge.capacity) {
                        parent[edge.to] = u;
                        visited[edge.to] = true;
                        queue.add(edge.to);
                        if (edge.to == t) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        int edmondsKarp(int s, int t) {
            int maxFlow = 0;
            int[] parent = new int[V];

            while (bfs(s, t, parent)) {
                int pathFlow = Integer.MAX_VALUE;
                for (int v = t; v != s; v = parent[v]) {
                    int u = parent[v];
                    for (Edge edge : adj[u]) {
                        if (edge.to == v && edge.flow < edge.capacity) {
                            pathFlow = Math.min(pathFlow, edge.capacity - edge.flow);
                            break;
                        }
                    }
                }

                for (int v = t; v != s; v = parent[v]) {
                    int u = parent[v];
                    for (Edge edge : adj[u]) {
                        if (edge.to == v && edge.flow < edge.capacity) {
                            edge.flow += pathFlow;
                            adj[edge.to].get(edge.rev).flow -= pathFlow;
                            break;
                        }
                    }
                }
                maxFlow += pathFlow;
            }
            return maxFlow;
        }
    }
}